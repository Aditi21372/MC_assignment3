package com.example.myapplication

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlin.math.abs

class SensorDataActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var db: SensorDatabase
    private var loading: MutableState<Boolean> = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)

        db = SensorDatabase.getDatabase(this)
        setContent {
            SensorDataScreen()
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (it.sensor.type == Sensor.TYPE_ACCELEROMETER) {


                val timestamp = System.currentTimeMillis()
                val sensorData = SensorEntity(timestamp = timestamp, xValue = it.values[0], yValue = it.values[1], zValue = it.values[2])

                lifecycleScope.launch {
                    val oldData = db.sensorDao().getLastRecord()
                    val tolerance = 0.01
                    val minTimeDiff = 1
                    if (oldData == null ||
                        abs(oldData.xValue - sensorData.xValue) > tolerance ||
                        abs(oldData.yValue - sensorData.yValue) > tolerance ||
                        abs(oldData.zValue - sensorData.zValue) > tolerance ||
                        timestamp - oldData.timestamp > minTimeDiff) {
                        db.sensorDao().insert(sensorData)
                    }
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {

    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
    }

    @Composable
    fun SensorDataScreen() {
        val xAxisData = remember { mutableStateOf(emptyList<Float>()) }
        val yAxisData = remember { mutableStateOf(emptyList<Float>()) }
        val zAxisData = remember { mutableStateOf(emptyList<Float>()) }
        val (refreshNeeded, setRefreshNeeded) = remember { mutableStateOf(false) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(onClick = {
                    setRefreshNeeded(true)
                    loading.value = true
                }) {
                    Text("Refresh")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            if (loading.value) {
                CircularProgressIndicator(modifier = Modifier.size(50.dp))
            } else {
                SensorGraph("X Axis", xAxisData.value)
                Spacer(modifier = Modifier.height(12.dp))
                SensorGraph("Y Axis", yAxisData.value)
                Spacer(modifier = Modifier.height(12.dp))
                SensorGraph("Z Axis", zAxisData.value)
            }
        }

        LaunchedEffect(refreshNeeded) {
            if (refreshNeeded) {
                val latestData = db.sensorDao().getLast10000()
                xAxisData.value = latestData.map { it.xValue }
                yAxisData.value = latestData.map { it.yValue }
                zAxisData.value = latestData.map { it.zValue }
                setRefreshNeeded(false)
                loading.value = false
            }
        }
    }


}
