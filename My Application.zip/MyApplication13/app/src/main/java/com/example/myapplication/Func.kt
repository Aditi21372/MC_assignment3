package com.example.myapplication

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun SensorGraph(axisLabel: String, data: List<Float>) {


    val maxValue = data.maxOrNull() ?: 1f
    val minValue = data.minOrNull() ?: 0f

    Column {
        Text(
            text = axisLabel,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            textAlign = TextAlign.Center
        )
        Canvas(
            modifier = Modifier
                .height(200.dp)
                .fillMaxWidth()
        ) {
            val widthPerPoint = size.width / (data.size - 1)
            val heightScale = size.height / (maxValue - minValue)

            for (i in 1 until data.size) {
                val x1 = widthPerPoint * (i - 1)
                val y1 = size.height - ((data[i - 1] - minValue) * heightScale)
                val x2 = widthPerPoint * i
                val y2 = size.height - ((data[i] - minValue) * heightScale)

                drawLine(
                    start = Offset(x1, y1),
                    end = Offset(x2, y2),
                    color = Color.Blue,
                    strokeWidth = 3f
                )
            }
        }
    }
}