package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.myapplication.ml.MobilenetV110224Quant
import com.example.myapplication.ui.theme.MyApplicationTheme
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.model.Model
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val labelsFromFile = application.assets.open("labels_mobilenet_quant_v1_224.txt").bufferedReader().readLines()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ImagePredictionUI(labelsFromFile)
                }
            }
        }
    }
}

@Composable
fun ImagePredictionUI(labels: List<String>) {
    var selectedBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var predictionText by remember { mutableStateOf("Result will be displayed here.") }
    var isLoadingPrediction by remember { mutableStateOf(false) }
    val currentContext = LocalContext.current

    // ActivityResultLauncher for picking image
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                val inputStream = currentContext.contentResolver.openInputStream(uri)
                inputStream?.use {
                    val bitmap = android.graphics.BitmapFactory.decodeStream(it)
                    selectedBitmap = bitmap
                }
            }
        }
    }
    val imageProcessor = ImageProcessor.Builder().add(ResizeOp(224, 224, ResizeOp.ResizeMethod.BILINEAR)).build()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        selectedBitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = "Uploaded Image",
                modifier = Modifier.height(250.dp).fillMaxWidth()
            )
        } ?: Text("No image selected", modifier = Modifier.padding(16.dp))

        OutlinedButton(
            onClick = {
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "image/*"
                imagePickerLauncher.launch(intent)
            },
            modifier = Modifier.padding(vertical = 16.dp),
            shape = MaterialTheme.shapes.small
        ) {
            Text("Upload Image")
        }

        Button(
            onClick = {
                isLoadingPrediction = true
                selectedBitmap?.let { bitmap ->
                    var tensorImage = TensorImage(DataType.UINT8)
                    tensorImage.load(bitmap)
                    tensorImage = imageProcessor.process(tensorImage)

                    val modelOptions = Model.Options.Builder()
                        .setDevice(Model.Device.NNAPI)
                        .build()

                    val mobilenetModel = MobilenetV110224Quant.newInstance(currentContext, modelOptions)

                    // Creates inputs for reference.
                    val inputFeature = TensorBuffer.createFixedSize(intArrayOf(1, 224, 224, 3), DataType.UINT8)
                    inputFeature.loadBuffer(tensorImage.buffer)

                    // Runs model inference and gets result.
                    val outputs = mobilenetModel.process(inputFeature)
                    val outputFeature = outputs.outputFeature0AsTensorBuffer.floatArray

                    val maxIndex = outputFeature.indices.maxBy { outputFeature[it] } ?: -1

                    // Releases model resources if no longer used.
                    mobilenetModel.close()

                    // Update prediction result
                    predictionText = labels[maxIndex]
                }
                isLoadingPrediction = false
            },
            modifier = Modifier.padding(vertical = 16.dp),
            shape = MaterialTheme.shapes.small
        ) {
            Text("Predict")
        }

        if (isLoadingPrediction) {
            CircularProgressIndicator()
        } else {
            Text(
                text = predictionText,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
        }
    }
}